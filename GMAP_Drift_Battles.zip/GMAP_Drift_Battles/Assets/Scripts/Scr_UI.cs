﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Scr_UI : MonoBehaviour {

    // Variables

    //UI
    public static Text combo_Text_p1;
    public static Text combo_Text_p2;

    // Use this for initialization
    void Start () {

        //Default UI elements
        combo_Text_p1 = transform.GetChild(0).GetComponent<Text>();
        combo_Text_p2 = transform.GetChild(1).GetComponent<Text>();

    }
	
	// Update is called once per frame
	void Update () {
		
	}




    public static void update_combo_text(int combo, bool is_player_one)
    {
        if(is_player_one)
        {
            combo_Text_p1.text = combo.ToString();
        }
        else
        {
            combo_Text_p2.text = combo.ToString();
        }
    }
}
