﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scr_Player : MonoBehaviour {

    //Variables
    
    //Player
    public bool is_player_one;
    public enum states { resting, drifting, bouncing };
    public states current_state;

    //Controllers
    public string Horizontal;
    public string Vertical;
    public string Drift;

    //Combat
    public int combo;

    // Use this for initialization
    void Start () {

        //Set controllers
        Scr_Controllers.set_controls(is_player_one, ref Horizontal, ref Vertical, ref Drift);

        current_state = states.resting;

        combo = 0;

    }
	
	// Update is called once per frame
	void Update () {

        Scr_Controllers.set_controls(is_player_one, ref Horizontal, ref Vertical, ref Drift);

    }






    public void update_combo(int i)
    {
        if (i != 0)
        {
            combo += i;
        }
        else
        {
            combo = 0;
        }

        Scr_UI.update_combo_text(combo, is_player_one);
    }

    public void set_state_resting()
    {
        current_state = states.resting;
    }

    public void set_state_drifting()
    {
        current_state = states.drifting;
    }

    public void set_state_bouncing()
    {
        current_state = states.bouncing;
    }

}
