﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class My_Systems : MonoBehaviour {

    //Variables

    //OS
    public static RuntimePlatform my_platform;

    // Use this for initialization
    void Start () {
        my_platform = Application.platform;
    }
	
	// Update is called once per frame
	void Update () {

        if (Input.GetButtonDown("Quit"))
        {
            Application.Quit();
        }
		
	}




}
