﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scr_Controllers : MonoBehaviour {

    //Variables

    //Controllers
    public static string[] Controllers;
    public static string check_mac;

    // Use this for initialization
    void Start () {

        check_mac = My_Systems.my_platform.ToString().Substring(0, 3);

        //Set controllers
        Controllers = Input.GetJoystickNames();

    }
	
	// Update is called once per frame
	void Update () {
        check_mac = My_Systems.my_platform.ToString().Substring(0, 3);
    }



    public static void set_controls(bool is_player_one, ref string Horizontal, ref string Vertical, ref string Drift)
    {
        Controllers = Input.GetJoystickNames();


        if (check_mac == "OSX")
        {
            if (is_player_one)
            {
                Horizontal = "Horizontal1";
                Vertical = "Vertical1";

                if (Controllers[0].Length == 19)
                {
                    Drift = "MacPS4Drift1";
                }
                else if (Controllers[0].Length == 28)
                {
                    Drift = "Mac360Drift1";
                }
                else if (Controllers[0].Length == 33)
                {
                    Drift = "MacOneDrift1";
                }
            }
            else
            {
                Horizontal = "Horizontal2";
                Vertical = "Vertical2";

                if (Controllers[1].Length == 19)
                {
                    Drift = "MacPS4Drift2";
                }
                else if (Controllers[1].Length == 28)
                {
                    Drift = "Mac360Drift2";
                }
                else if (Controllers[1].Length == 33)
                {
                    Drift = "MacOneDrift2";
                }
            }
        }
        else
        {
            if (is_player_one)
            {
                Horizontal = "Horizontal1";
                Vertical = "Vertical1";

                if (Controllers[0].Length == 19)
                {
                    Drift = "PS4Drift1";
                }
                else if (Controllers[0].Length == 28)
                {
                    Drift = "360Drift1";
                }
                else if (Controllers[0].Length == 33)
                {
                    Drift = "OneDrift1";
                }
            }
            else
            {
                Horizontal = "Horizontal2";
                Vertical = "Vertical2";

                if (Controllers[1].Length == 19)
                {
                    Drift = "PS4Drift2";
                }
                else if (Controllers[1].Length == 28)
                {
                    Drift = "360Drift2";
                }
                else if (Controllers[1].Length == 33)
                {
                    Drift = "OneDrift2";
                }
            }
        }
    }
}
