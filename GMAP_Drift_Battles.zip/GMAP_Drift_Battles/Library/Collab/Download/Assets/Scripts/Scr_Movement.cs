﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class Scr_Movement : MonoBehaviour {

    //Components
    private Rigidbody2D rb2d;

    //Variables

    //Player
    private Scr_Player scr_player;
    private bool is_player_one;
    private Scr_Player.states current_state;

    //Controllers
    private string Horizontal;
    private string Vertical;
    private string Drift;

    //Movement
    public float bounce_speed; //10
    public float drift_speed; //85

    private float axis_h;
    private float axis_v;
    public Vector3 dir_move;

    //Timing
    public float drift_timer; //0.1
    private float drift_reset;
    public float combo_timer; //0.2
    private float combo_reset;
    public float bounce_timer; //0.6
    private float bounce_reset;

    //Combat
    private int combo;






    // Use this for initialization
    void Start () {

        //Player rigidbody
        rb2d = GetComponent<Rigidbody2D>();

        // Other Script Vars
        scr_player = GetComponent<Scr_Player>();
        is_player_one = scr_player.is_player_one;
        current_state = scr_player.current_state;
        combo = scr_player.combo;

        //Set controllers
        Scr_Controllers.set_controls(is_player_one, ref Horizontal, ref Vertical, ref Drift);

        //Default not moving player
        axis_h = 0;
        axis_v = 0;
        dir_move = Vector3.zero;

        //Timer resets
        combo_reset = combo_timer;
        drift_reset = drift_timer;
        bounce_reset = bounce_timer;

        combo_timer = 0;

    }






    // Update is called once per frame
    void Update () {

        // Other Script Vars
        scr_player = GetComponent<Scr_Player>();
        current_state = scr_player.current_state;
        combo = scr_player.combo;

        if (current_state == Scr_Player.states.resting)  // START RESTING
        {
            update_combo_timer();


            rb2d.velocity = Vector3.zero;


            update_dir();


            if (dir_move != Vector3.zero)
            {
                if (Input.GetButtonDown(Drift))
                {
                    scr_player.current_state = Scr_Player.states.drifting;
                    scr_player.update_combo(1);
                }
            }
        }
        else if (current_state == Scr_Player.states.drifting) // START DRIFTING
        {
            rb2d.velocity = dir_move * drift_speed;
            drift_timer -= Time.deltaTime;
            if (drift_timer <= 0)
            {
                scr_player.current_state = Scr_Player.states.resting;
                drift_timer = drift_reset;
                combo_timer = combo_reset;
            }
        }
        else if (current_state == Scr_Player.states.bouncing) // START BOUNCING
        {
            update_combo_timer();


            rb2d.velocity = dir_move * -1 * bounce_speed;
            bounce_timer -= Time.deltaTime;
            if (bounce_timer <= 0)
            {
                scr_player.current_state = Scr_Player.states.resting;
                bounce_timer = bounce_reset;
            }
        }
    }




    //Collisions
    void OnCollisionEnter2D(Collision2D other)
    {

        if (other.gameObject.tag == "Stop")
        {
            set_up_bounce();
        }



        if (other.gameObject.tag == "Player")
        {
            other.rigidbody.velocity = Vector3.zero;
            if (other.gameObject.GetComponent<Scr_Movement>().combo < combo)
            {
                Destroy(other.gameObject);
            }
            else if (other.gameObject.GetComponent<Scr_Movement>().combo == combo)
            {
                set_up_bounce();
            }
        }
    }



    void update_combo_timer()
    {
        combo_timer -= Time.deltaTime;
        if (combo_timer <= 0)
        {
            scr_player.update_combo(0);
        }
    }

    void set_up_bounce()
    {
        scr_player.current_state = Scr_Player.states.bouncing;
        rb2d.velocity = Vector3.zero;
        drift_timer = drift_reset;
        combo_timer = 0;
        scr_player.update_combo(0);
    }


    void update_dir()
    {
        //Get X and Y Axis Input
        axis_h = Input.GetAxisRaw(Horizontal);
        axis_v = Input.GetAxisRaw(Vertical);

        //Input Vector
        dir_move = new Vector3(axis_h, axis_v);

        //Normalize to make diaganals not sqrt(2)
        dir_move = dir_move.normalized;
    }
}
